# Open Image in Full Page Context Menu

Chrome extension for opening an image in a new tab that can be used to print it in full page.
